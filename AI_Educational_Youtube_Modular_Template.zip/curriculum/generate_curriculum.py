# generates enriched_lesson_data.json
