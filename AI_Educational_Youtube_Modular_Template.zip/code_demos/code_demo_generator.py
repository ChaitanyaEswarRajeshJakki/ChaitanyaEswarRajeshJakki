# generates code demos from lesson content
