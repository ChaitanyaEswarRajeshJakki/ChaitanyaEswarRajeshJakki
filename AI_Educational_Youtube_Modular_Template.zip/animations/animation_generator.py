# generates animations using manim or similar
