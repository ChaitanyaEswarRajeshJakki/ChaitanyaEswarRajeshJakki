import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./smarthire.db")
JWT_SECRET = os.getenv("JWT_SECRET", "supersecret")