from fastapi import APIRouter

router = APIRouter()

@router.post('/ask')
def ask_chat():
    return {"msg": "LLM response"}