from fastapi import APIRouter

router = APIRouter()

@router.post('/register')
def register():
    return {"msg": "Register endpoint"}

@router.post('/login')
def login():
    return {"msg": "Login endpoint"}