from fastapi import APIRouter

router = APIRouter()

@router.post('/upload')
def upload_job():
    return {"msg": "Job uploaded"}