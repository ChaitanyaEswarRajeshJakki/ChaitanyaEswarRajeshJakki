from pydantic import BaseModel

class ResumeUpload(BaseModel):
    filename: str
    content: str