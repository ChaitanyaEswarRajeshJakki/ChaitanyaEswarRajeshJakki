from pydantic import BaseModel

class ChatRequest(BaseModel):
    role: str  # recruiter or candidate
    input_text: str
    resume_id: int = None
    job_id: int = None