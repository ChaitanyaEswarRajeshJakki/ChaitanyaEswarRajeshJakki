from sqlalchemy import Column, Integer, String, ForeignKey, Text
from app.core.database import Base

class JobDescription(Base):
    __tablename__ = 'job_descriptions'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String)
    description = Column(Text)
    skills = Column(Text)