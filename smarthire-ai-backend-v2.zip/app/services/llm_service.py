import openai

def analyze_fitment(resume_text: str, jd_text: str) -> dict:
    prompt = f"""You are an HR assistant. Analyze the following resume against this job description.

    JD:
{jd_text}

Resume:
{resume_text}

Provide a match score (1-100), candidate strengths, and gaps."""

    # Use OpenAI GPT for now (replace with Ollama later if needed)
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=500
    )
    return response['choices'][0]['message']['content']